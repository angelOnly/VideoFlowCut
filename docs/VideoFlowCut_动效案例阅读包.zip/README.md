# VideoFlowCut 动效案例阅读包

这是已有动效材料的独立待评审快照，供你观看效果、阅读设计理由和源码。没有执行安装、改动仓库或合并 GitHub 提交。

## 先打开什么

1. [完整开发方案](完整开发方案.md)：最初整条创作链路与后续案例库已合并，开发前以这份完整提案和你的明确批准范围为准。
2. [总动效 Skill](motion-case-library/SKILL.md)：共同设计特征、选型、迁移方式与各案例索引。
3. 按下表分别观看视频、阅读该例 Skill。一个视频就是一个动效，未拼成合集。

| 案例 | 设计说明 | 独立效果 | 源码 | 实际输入 |
| --- | --- | --- | --- | --- |
| 票据展开与条款 | [案例 Skill](motion-case-ticket-rules/SKILL.md) | [ticket-rules.mp4](motion-case-ticket-rules/assets/ticket-rules.mp4) | [motion.tsx](motion-case-ticket-rules/assets/motion.tsx) | [fixture.json](motion-case-ticket-rules/assets/fixture.json) |
| 产品增殖与收拢 | [案例 Skill](motion-case-product-multiply/SKILL.md) | [product-multiply.mp4](motion-case-product-multiply/assets/product-multiply.mp4) | [motion.tsx](motion-case-product-multiply/assets/motion.tsx) | [fixture.json](motion-case-product-multiply/assets/fixture.json) |
| 时钟与参照变化 | [案例 Skill](motion-case-clock-shift/SKILL.md) | [clock-shift.mp4](motion-case-clock-shift/assets/clock-shift.mp4) | [motion.tsx](motion-case-clock-shift/assets/motion.tsx) | [fixture.json](motion-case-clock-shift/assets/fixture.json) |
| 通道瓶颈与分配 | [案例 Skill](motion-case-capacity-stream/SKILL.md) | [capacity-stream.mp4](motion-case-capacity-stream/assets/capacity-stream.mp4) | [motion.tsx](motion-case-capacity-stream/assets/motion.tsx) | [fixture.json](motion-case-capacity-stream/assets/fixture.json) |

每段均为 720×1280、30 fps、14 秒、无声。它们是独立教学作品，尚不代表数字人／字幕／声音合成或整片连续性已经通过。

## 辅助资料

- [四站参考选型示范](motion-case-library/references/four-source-worked-example.md)
- [实际观察到的机制与边界](motion-case-library/references/observed-mechanisms.md)

## 阅读与开发的区别

这五份 Skills 和其源码、输入、视频均原样取自此前待审材料，来源提交为 `1ff994efe3ac0cb6406ab29795cea0f220b5c1ac`，本次没有修改它们。包内不是一套已批准安装的插件或可独立运行的 Remotion 项目。

Skill 中的 `../remotion-production/SKILL.md` 是接入 VideoFlowCut 后的项目生产入口，不在本阅读包内。所有四案例、独立效果、源码、参数和总 Skill 的相对链接在包内可达。包中提到的 `npm run motion:cases` 属于原项目草稿，本包没有完整 package 依赖，不能直接把它当作解压后的运行命令。

当前总 Skill 中的四站必填要求说明旧平台合同。完整方案已规定将其改为创作说明与可选参考；只有经批准开发并发布该合同后才能切换，阅读包不会自动完成接口开发。

四份 Fixture 的 beats 存在两种结构，适合阅读，后续若要统一自动读取应在批准范围内规范。完整方案建议追加的四张关键帧图尚不在这批既有材料里。

GitHub 上的原材料仍属于未批准草稿。本阅读包用于评审，不是要求你合并或部署该草稿。后续 Codex 必须先确认你明确批准的开发范围。
