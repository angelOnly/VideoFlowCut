# 素材查询、取得与本地化

## 来源研究与素材取得

接到探索或定向补材任务，先读取导演准确句群、画面意图、具体取材请求与已有候选，用主体、行为、细节和材料之间的关系寻找内容。项目材料和网络来源均可参与；先发现能承担本段画面的内容，再根据实际来源选择取得方式。

查询根据实际结果调整，不按真实事件、生活情境或产品类别固定网站与媒介。找到更贴切的材料，说明它能接哪句话、改变什么画面，交导演与文案更新当前稿；不把标题或缩略图说成已经看见的动作。

探索阶段通过现有 manage_asset_requirements 建立具体需求，不必虚构 Scene 或固定时长。需求创建、下载、分析提交与正式采用由主任务执行；本专项负责完整参数和实际选材判断。搜索和读取使用本次实际可用的宿主浏览器与 MCP；浏览器可查找、阅读、复制真实文字和获取可公开下载的文件，正式入库仍由主任务通过已发布 MCP 获取或导入。缺少能力时报告具体缺口，不用 shell 或浏览器脚本绕过项目写入。

候选足以影响讲述时，尽早将实际发现交回文案作者和导演：发生了什么、支持哪句话、需要改哪项判断、有哪些可发展的画面、还有什么未确认。不必等所有镜头下载完才反馈。导演采用方向后，再补连续源范围、裁切、原声和接点。

首次按观察过程寻找材料，或当前结果只有相关插图时，完整读取 [从问题到可剪材料](source-review.md)，学习查询怎样依据候选改变；不按示例固定执行搜索次数。

按需读取[源素材观察方法](source-review.md)。当前由宿主浏览器搜索、阅读并摘录真实原文，保留来源 URL、阅读范围和时间；通过 `acquire_source_material` 正式取得选定公开网页快照、直接图片或 PDF。`kind=web_snapshot` 使用固定 1440 像素视口，不传 `pages` 或 `pageWidth`；这两个字段只用于 PDF，`pageWidth` 是页面图片最长边像素。网页快照由服务重新获取，不等于浏览器当前页面选区；无法公开获取时交回具体缺口。Google 和 Pexels 网页搜索不需要 API Key；Pexels 选定视频页的正式获取另走下文 Provider 链路。图库用 `nextCursor` 继续，变更查询、服务或媒体类型时重新开始。

## 当前能力与计划能力

独立音效的功能与音色选择由 `audio-finishing` 负责，不套视觉构图标准。它复用 AssetRequest → Candidate → 本地 Asset 的获取合同：media_kind=audio、audio_brief、sfx/bgm 角色，无需画幅。`browse_sound_sources` 返回来源与访问边界，Mixkit 的公开分类已接入现有 Provider；候选不自动进入 Timeline，其它站点使用实际可用的获取入口。不要为了声音需求调用生成画面的 fallback。

可选参考研究用于理解运动机制，不是原创二维对象的前置模板搜索。灵感、作品绑定图片、真实证据与实拍分别记录用途；只有实际使用的素材进入获取链。无原始文件时不能把预览当素材。

在线动效不是 Stock 下载任务。Onda、Jitter、RemotionLab、Mixkit 由 `browse_motion_sources` 提供入口，`inspect_motion_reference` 支持公开页面与动态采样。把选中链接和观察依据交给 `remotion-production`；无源码或 AE 格式不妨碍独立实现。只有确实要使用第三方图片、视频或音频时才进入本 Skill 的素材获取流程，不把参考预览登记成正式素材。

当前获取链包括 `manage_asset_requirements`、`search_media_candidates`、`inspect_media_candidate`、`acquire_media_asset` 和 `read_asset_provenance`。需求创建、修改与关闭使用创作 Revision；搜索意图、候选、来源和过滤结果保存于独立搜索会话，搜索本身不改变创作 Revision，也不下载或采用素材。

首次搜索先调用 `list_asset_providers`，直接使用返回的准确 `id`，核对 `enabled`、`mediaTypes`、`queryMode` 和缺失配置。品牌名不能代替服务标识，例如 Commons 的 id 是 `wikimedia-commons`。已注册不代表网络和下载器已经验证；当前自动搜索来源只保留无需 Key 的服务；无需 Key 不代表网络一定可达。公开材料获取使用运行环境已有的 HTTP(S) 代理和 NO_PROXY，每次跳转仍核验公网地址，并保留浏览器实际来源请求头。网页子资源失败可以保存当前截图；主任务读取 Job.result.capture 的 complete、warnings 与 reviewStatus，交回原文案或证据专项逐项核验正文、限定条件和缺失资源。reviewStatus=pending 表示待核验，complete 只表示请求是否有已知缺口，均不代表证据可用。统计等非 GET 请求不会发送，作为缺口记录；主页面失败、登录/验证码、安全限制和预算超限仍拒绝。某页失败不等于全部来源不可用，也不能把失败页面标记为已读取。需要连续实拍时给 `search_media_candidates` 显式传 `media_type="video"`，图片用 `image`；关键词里的 video 不保证媒体类型。

返回候选后先看 `diagnostics.complete` 和 `diagnostics.warnings`。部分详情失败时已有候选仍可检查，但未读取部分保留缺口，不能写成没有合适素材或全部检索完成。主任务只在错误明确携带 `sideEffects="none"`、`safeToRetry=true` 和具体恢复依据时，按目录纠正参数或等待 `retryAfterMs` 后再搜索一次；同因再次失败按 Repair Ticket 报障。下载、生成和写入的未知结果不适用该例外，不能由专项改代理、密钥或执行 shell。

视觉 Provider 保留无需 Key 的 Wikimedia Commons，以及选定单个视频页面的 YouTube、Pexels 获取合同；Pexels 的网页搜索与画面判断仍由宿主浏览器完成，选定页的原件由媒体 Worker 正式获取。配置 API Key 时也可用 Pexels 关键词搜索；实际可用性仍以当前 Runtime、正式工具返回和实时 Schema 为准，不把源码实现当成当前会话已发布能力。Creative Library、其他站点和通用网页证据获取不能只因出现在方案中就被视为已接入。网页调研、来源核实和将媒体正式取得为 Project Asset 是不同步骤；需要当前会话未提供的获取能力时按平台合同反馈。

查询后先查看候选来源、媒体类型、时长、构图与过滤理由，再决定获取。Worker 验证下载文件的 MIME、文件头、哈希和媒体流后登记 Asset，预览 URL 和 Candidate ID 不能直接进入 Scene、作品绑定或 Timeline。

MiniMax 已有独立的 `submit_video_generation`，支持文生、图生、首尾帧与多参考四种模式的提交合同，不经过 Stock Candidate 获取接口。使用已确认的 `workflow_id`，提交当前镜头提示词、生成源长度、画幅与必要的已就绪输入 Asset；Worker 实际调用前读取 Bridge Schema。枚举存在不等于当前工作流支持任意时长、分辨率或全部参考组合，不硬编码未验证的工作流和参数。

生成提示词写本镜主体与环境、动作怎样发展、取景与运镜、构图留白、进入和结束状态、连续性及需避免的内容错误。生成是首版分镜可主动选择的方式，适合示意、氛围或允许虚构的画面；事实内容可以由原创示意解释，但生成结果不能替代真实证据或冒充拍到的事件。`duration_seconds` 是待生成镜头的源长度，不自动等于整段叙事时长。

提交后通过 `track_job` 跟踪结果；只有 Worker 下载验证完成并读回真实 Asset，才进入正式内容复核。技术 ready 或需求 fulfilled 只表示文件已交付，不表示镜头表达与采用已经通过。失败或状态不确定时先读取现状和诊断，遵循幂等与报障合同，不换键猜测重试。生成依赖当前项目版本，执行期间按 Revision 合同协调写入，不能无条件并发改项目。

本地化或生成完成后，通过 `inspect_asset` 及媒体观察核对原文件实际动作、画质、声音和可用范围；模型摘要不替代必要实际观看。用 `adopt_media_fragment` 保存当前用途、范围、观察与原声策略，具体放置后用 `bind_media_adoption` 关联使用对象。候选、文件、内容合适和正式采用分别判断。

浏览器用于发现候选、阅读图片和文字所在页面、核实来源与查看可用预览，保存来源链接和实际观察。网页上的图像、视频预览与项目正式素材是不同状态；使用原图或页面证据时保留相应区域与上下文，经已发布的获取或导入路径进入项目，不能把浏览器缓存地址直接填入作品。

### Pexels 单视频页与 Worker 获取

素材专项先在宿主浏览器搜索 Pexels、观看候选，核对选定单视频页的实际画面、作者和拟用范围，再把准确的 HTTPS 单视频页 URL 与观察结果交给主任务。浏览器不承担下载文件和交回本地路径；搜索结果页、集合页、预览地址与缩略图不能替代单视频页。

主任务读取实时 Schema 和 `list_asset_providers`，用真实需求 ID、`provider="pexels"`、`query=选定页面URL` 调用 `search_media_candidates`；无 API Key 时不传关键词。平台在候选阶段检查公开下载入口是否指向同一视频的 MP4。主任务读取候选并提交 `acquire_media_asset`，再用 `track_job` 跟踪。媒体 Worker 重新核验入口与跳转，将原件保存到受管缓存，检查 MIME、大小、文件头、哈希与 ffprobe；只有通过并登记为 Asset 后，才读回真实时长和画面范围，交原素材专项与导演决定采用。

公开下载入口变化、返回外站地址、非 MP4、网络失败或媒体分析失败时保留 Job 诊断，先区分候选不适合、临时网络和服务故障。候选问题换来源；服务未就绪按已有授权恢复；仅确认平台或服务自身 Bug 且阻断工作才报修；不让素材专项执行 shell 或临时下载绕过。Pexels 单视频页的无 Key 获取依赖公开网页入口，稳定性低于官方 API。

YouTube 的已实现路径由平台执行 yt-dlp。专项先在浏览器调研中选出单个 HTTPS 视频页面并说明拟用范围，主任务以现有 `search_media_candidates` 提交 `provider="youtube"`、`query=选定页面URL` 与真实需求 ID；这里的 query 是单视频链接，不是关键词搜索。读取候选后，直接提交 `acquire_media_asset`。

默认取得选定视频的完整单文件；需要已定位片段时传 source_range_ms（原片毫秒范围），quality_height 可按画幅和裁切需要选择目标高度，省略使用项目画幅高度。先按画质选择，再在同档格式中优先HLS；源只有较低规格时如实使用，不固定封顶720p。所有分段必须完整，缺段立即失败，不以跳段后的残片冒充原片。分离音视频流由 yt-dlp 合并成 MP4；范围取得为精确切口可能重新编码，返回原片范围与本地零点对应，后续选段使用本地时间。不下载播放列表或拼接多个视频。最终文件与下载缓存保留实际大小和超时保护，片段不按整片预计大小拒绝；取得后自动探测真实媒体信息。已有观察、选段与用途继续使用，只核对质量、时间对应或上下文的实际变化。平台使用发行版固定的下载器依赖；剪辑任务不安装或升级下载器。访问失败、超限、超时、合并失败或无效输出沿现有 Job、幂等与 Repair Ticket 合同处理，未受影响的其他候选继续。

## 查询计划

先将导演的问题写成能在画面或声音里辨认的内容：谁在什么环境做什么，正在出现何种变化，需要哪些细节、结果、反应或现场声。审美和体验需求也要落实为可观察的光影、空间、材质、动作或声音特征，不能只把抽象情绪当作唯一关键词。

按候选实际提供的内容选择来源，项目材料、原拍、报道、评测、体验、回放、集锦、二创与其他媒介均可比较。需要连续动作时查看真实源范围，事实依据保留上下文，不把来源类别当作固定路线。

从主体名称、动作、环境、拍摄形式和必要构图组合少量查询，按来源语言尝试准确的中英文表达。先保留必须满足的条件，允许景别、色调等未锁定条件有候选差异；不一开始把尚未决定的参数全部设成硬过滤。完整旁白不作为唯一检索句。

根据结果改查询：只有主题氛围而缺行为，就换动作和来源；缺结果或反应，就看前后片段、同系列或同作者相关记录；具体对象不符就细化名称。记录实际找到什么、为什么改搜法，而不以搜索次数表示完成。找到足以判断关键方向的材料即交导演，其余按明确分镜继续补齐。

## 来源

候选记录真实来源页面、作者、取得时间和使用范围；未知明确保留。YouTube 单页候选和整文件下载按上述实现合同及现场实时 Schema 执行；浏览器用于搜索、阅读图片文字与核实页面证据，技术上可以下载不等于内容已经适合当前分镜，也不自动改变素材的来源或用途状态。网页证据保留原始上下文与目标区域，区分原文、项目高亮与原创示意；下载、受管导入、内容复核和具体采用各保留实际结果。

## Acquire 与本地化

被接受的 Candidate 必须先下载到临时目录，验证 HTTP、MIME、文件头、大小、哈希和 ffprobe，再移到项目受管目录并注册 Asset。HTML 错误页不能因扩展名 mp4 被接受。Timeline 和 Remotion 只能引用本地 Asset ID，不长期依赖 Provider URL。

获取结果与 `read_media_observations` 的 `candidateEvidence` 保留已有候选观察、原始范围和上下文。作者确认同一来源及时间对应后，`adopt_media_fragment.input.candidateSourceStartMs` 填候选观察零点在原片中的位置，`range` 填本地文件范围。平台按取得片段的原片起点换算覆盖，原观察与未知项保留原身份；不需要重复分析，也不能把缩略图或未观看范围当连续证据。图片若沿用同一候选图像观察，零点填0，当前裁切改变时补核对受影响部分。

## 根据实际缺口选择继续搜索、生成与原创

每次把未解决项说明到内容层：没有找到所需行为，现有范围缺少结果或反应，画幅裁切破坏主体，原声被覆盖，素材事实不符，或者取得方式不可用。分别修改动作词与来源、查看同源前后范围、寻找互补镜头或提出新的表现建议；不只重复搜索主题或加“高清、电影感”。

已有素材、网络获取、MiniMax 生成与原创动效按镜头用途主动组合，不排固定降级顺序。事实无依据先核实；表达关系可改为明确示意、图形或允许虚构的生成镜头；已拍过程不能由生成画面冒充。若必须改变关键画面、故事顺序或主声音，带可行方案及影响交导演判断。

已经找到足以试排关键段落的材料，就交导演查看和粗剪，留下普通补材需求；不等所有备选搜尽。若连续结果只重复同类弱相关内容，应说明这一轮尝试及无效原因，返回具体缺口，而不是无限下载。搜索停止不等于内容问题解决，未完成项继续可见。

来源不可访问、下载或 Runtime 失败由主任务保留诊断并执行已授权恢复，仅确认平台或服务自身 Bug 阻断任务才报修；专业选择不合适回原专项，跨段表达冲突回导演。未知写入结果先对账，不重放获取或导入，不把工具失败换成“已经做出安静区”。

## 工具状态必须明确区分

### 公共素材理解与声音链

`retry_media_job(project_id?, job_id)` 只恢复已失败/取消的素材理解、片段检索或声音排序，保存原检查点；有 run ID 继续读，提交结果未知时不重放 POST。Web 任务中心遵循相同恢复原则。

`bind_media_adoption(project_id?, input)` 输入 baseRevision、adoptionId 和 target：timelineItemId、外层 effectCueId+slot、内部 effectCueId+motionImageSlot 或 effectCueId+motionVideoSlot，按实时 Schema 选择一种，不混用。内部图片槽对应固定 imageBindings，旧图片摘要只从同版成功 Job 核验恢复；不是外层 slot=motion，也不猜历史视频范围。核验实际原文件、范围并关联具体使用；静音策略落实到实际播放。放置后绑定，改范围、换作品版本、原文件或上下文后重新确认。音效通过 manage_audio 的 design.adoptionId 关联，不必重复此步。

`analyze_media(project_id?, input)` 的 input 使用 assetId 或 candidateId、depth、modalities，以及源毫秒 range 或图片/PDF region；HTTP 模型任务返回 Job，不改 Revision。`read_media_observations(project_id?, input)` 按 offset/limit 分页；`search_media_fragments(project_id?, query, mode)` 的 hybrid 返回 Job、lexical 返回已有事实匹配。处理成功、事实覆盖、使用可行性分别读取。

`correct_media_observation(project_id?, input)` 保存 observationId、facts、unknowns、reason、author；影响采用时提供 baseRevision。`adopt_media_fragment(project_id?, input)` 提供 baseRevision、assetId、observationIds、range/region、当前 requestId/requestVersion、purpose、audioPolicy、conditions；实际原文件哈希与范围必须成立。

声音计划、候选比较和混音操作按需读取[声音操作](../../audio-finishing/references/audio-operations.md)。

## 当前调用与读回：素材需求与候选

| 阶段 | 当前 MCP 命令与关键输入 | 写后读回 / 下一步 |
|---|---|---|
| 素材需求与候选 | `list_asset_providers()`；`manage_asset_requirements(base_revision_id, action, ...)`；`search_media_candidates(base_revision_id, asset_request_id, provider, query, media_type?)`；`inspect_media_candidate(asset_candidate_id)` | 先用目录的准确 id 与支持类型；搜索只保存独立会话与候选，不增加创作 Revision。检查 diagnostics 是否完整，候选不能直接进入 Scene 或 Timeline。 |

## 当前调用与读回：下载与本地化

| 阶段 | 当前 MCP 命令与关键输入 | 写后读回 / 下一步 |
|---|---|---|
| 下载与本地化 | `acquire_media_asset(base_revision_id, asset_candidate_id, idempotency_key?)`；`track_job(job_id)`；`read_asset_provenance(asset_id)` | Worker 校验 MIME、文件头、内容哈希和 ffprobe 后才注册 Asset，并继续创建媒体分析任务；确认 ready 前不能视为可渲染素材。 |

### YouTube 单视频获取与用途依据

`search_media_candidates(base_revision_id, asset_request_id, provider="youtube", query=选定单个HTTPS视频URL)` 读取所选视频页面的元数据，query 不是关键词、频道或播放列表。它沿独立搜索会话保存候选、来源和过滤结果，不下载、不自动采用，也不改变创作 Revision。使用前仍须确认当前 Runtime 已提供对应 Provider。

素材搜索返回结构化错误时，仅 `sideEffects="none"`、`safeToRetry=true` 且具备明确恢复依据的情况，允许依目录纠正或等待 `retryAfterMs` 后再搜索一次；同因再次失败即报障。不得把此规则套到 `acquire_media_asset`、生成、创作写入和未知结果。`diagnostics.complete=false` 的部分搜索可检查已有候选，但不能当成全量检索；后续完整查询不会复用残缺搜索缓存。

`acquire_media_asset(base_revision_id, asset_candidate_id, idempotency_key?)` 不接受权利或用途证明参数。Worker 下载验证后登记 Asset，继续媒体分析；读回 ready、来源和具体源范围后，沿现有采用链保存内容判断。

YouTube 获取范围、画质选择、合并与缓存边界沿本页“当前能力与计划能力”中的现行合同执行，不重复维护旧的固定分辨率与整条下载限制。文件取得只证明获取结果，不证明镜头适合分镜或艺术验收完成。
